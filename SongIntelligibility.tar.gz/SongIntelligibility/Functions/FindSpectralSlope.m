% clc;
% clear all;
% close all;
% [s fs]=wavread('/home/queen/PHD/HTS_CMU_ARCTIC/cmu_us_slt_arctic/wav_8k/arctic_a0001.wav');
function [AllSlope AllSpectrum]=FindSpectralSlope(s,fs,fsizems,fshiftms)
s=s./1.01*max(abs(s));

Nfft=2048;
lporder=20;%(fs/1000)+4;

% addpath('/home/queen/PHD/formant_enhancement');
% addpath('/home/queen/PHD/syll_rate/All_evidences/');
[res1,LPCs1] = LPres(s,fs,fsizems,fshiftms,lporder,1);
S=size(LPCs1);

AllSlope=[];
AllSpectrum=[];
for i=1:S(1)

LPCs11=LPCs1(i,:);
[All_H1]= find_spectrum3(LPCs11,fs);
All_H1=abs(abs(All_H1));
All_H1=All_H1./max(All_H1);
All_H1=20*log10(All_H1);

x_axis=((fs/2)/1025)*(1:1025);
x_axis=log10(x_axis);

x1 = 1:length(All_H1);
p1 = polyfit(x_axis,All_H1',1);
y1 = polyval(p1,x_axis);
%figure;plot(x_axis,y1);

slope_ori=p1(1)*(6/20);
AllSlope=[AllSlope slope_ori];
AllSpectrum=[AllSpectrum All_H1];
end
