


function [slope1 pre_dip_loc1 suc_dip_loc1]= henv_slope_function(x,fs,hensp1,epochlocs1)
%x=x./max(abs(x));


s1=x;%x(19284: 21178);

%epochlocs1=unique(epochlocs1);
[pre_dip_loc1 pre_dip_val1]=find_preceeding_dip(epochlocs1,hensp1,0.5);
[suc_dip_loc1 suc_dip_val1]=find_succeeding_dips(epochlocs1,hensp1,0.5);
slope_p1=(hensp1(epochlocs1)-pre_dip_val1)./(epochlocs1-pre_dip_loc1);
slope_s1=(hensp1(epochlocs1)-suc_dip_val1)./(suc_dip_loc1-epochlocs1);

%slope_p1=slope_p1./max(slope_p1);
%slope_s1=slope_s1./max(slope_s1);
slope=(slope_s1+slope_p1)./2;
slope1=slope;

 