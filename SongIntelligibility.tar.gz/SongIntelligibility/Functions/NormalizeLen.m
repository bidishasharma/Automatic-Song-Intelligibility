function [Feat1]=NormalizeLen(Feat,len1)
%%Feat = 1xM matrix
L=length(Feat);

if len1>L
 difr=len1-L;
  Feat1=[Feat repmat(Feat(end), 1, difr)];
elseif len1<L
  Feat1=Feat(1:len1);
else
 Feat1=Feat; 
end   