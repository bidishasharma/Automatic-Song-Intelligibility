function [fin_cor] = SuprasgmentalFeat(s,fs,ngdloc)
s=preemphasize(s,0.5);
lporder=fs/1000+4;
ressp1=LPres(s,fs,20,10,lporder,1);
ressp1=ressp1./(1.01*max(abs(ressp1)));
hensp1=HilbertEnv(ressp1,fs,1);
hensp1=hensp1./(max(abs(hensp1)));   

for p=1:length(ngdloc)
    strt=round(ngdloc(p)-1.5*10^-3*fs);
    stpt=round(ngdloc(p)+1.5*10^-3*fs);
    req_len=stpt-strt;
    if (strt<1)
       % continue
       strt=1;
       stpt=strt+req_len;
    end  
   if (stpt>=length(hensp1))
       % continue
       stpt=length(hensp1);
   end  
   array=abs(s(strt:stpt));
   PitchCycl(:,p)=array;   
    
end;

%%%%%%%%%%%%%%%%%%%%SUPRASEGMENTAL%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fin_cor=zeros(1,length(ngdloc));
K=6;%ACR order
if K>=length(ngdloc)
    K=length(ngdloc)-1;
end;

for q=1:length(ngdloc)-K
        cor1=0;
        for l=1:K         
            x= PitchCycl(:,q);
            y1=PitchCycl(:,q+l-1);   
            norm_factor=sqrt(sum(x.^2)*sum(y1.^2));
            tmp=sum(x.*y1)./norm_factor;
            cor1=cor1+tmp;
        end

fin_cor(q)=cor1;
end
fin_cor(q+1:length(ngdloc))=cor1;
fin_cor=(fin_cor-min(fin_cor))/(max(fin_cor)-min(fin_cor));




