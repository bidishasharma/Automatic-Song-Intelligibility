function [ featureVector ] = ExtractFeaturesMFCCs( filePath,FRAMESIZE,HOPSIZE )
%UNTITLED9 Summary of this function goes here
%   Detailed explanation goes here


[audio,SAMPLERATE] = audioread(filePath); 
if SAMPLERATE < 20000
    audio = resample(audio,22050,SAMPLERATE);   %resample the audio to at least 22050 (pitchscales are up to 10000 Hz for E6 Note, fs/2 need to be more than 1000) 
    SAMPLERATE = 22050;
end
if (size(audio,2) == 2)
	audio = audio(:,1)/2 + audio(:,2)/2;
end

%[ fluct,fluctVariance , SpectralFlatness, meanSpectralFlatness , spectral_contraction, varspectralContraction   ] = Fluct_Flat_Contr( audio, SAMPLERATE,FRAMESIZE,HOPSIZE );

%vocalVariance = VocalVariance(audio,SAMPLERATE, FRAMESIZE, HOPSIZE);
mfccs = melcepst(audio,SAMPLERATE,'d',17,floor(3*log(SAMPLERATE)),FRAMESIZE,HOPSIZE);
%featureVector = [fluctVariance, vocalVariance, meanSpectralFlatness,varspectralContraction,mfccs] ; 
featureVector = [mfccs] ; 

%% old feature extraction 
%[fluct,fluctVariance] = Fluctogram(audio,SAMPLERATE);
%[SpectralFlatness, meanSpectralFlatness] = Flatness_Bands_ForFile(audio,SAMPLERATE);
%[spectral_contraction, varspectralContraction] = SpectralContraction(audio,SAMPLERATE);

end

