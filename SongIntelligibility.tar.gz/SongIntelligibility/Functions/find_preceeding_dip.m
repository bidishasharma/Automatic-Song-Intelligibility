function [pre_dip_loc pre_dip_val]=find_preceeding_dip(epochlocs1,hensp1,thresh)

hensp1=hensp1./max(hensp1);
for i=1:length(epochlocs1)
    
    if(i==1)
     strt=1;
     stpt=epochlocs1(i);
    else
    strt=epochlocs1(i-1);
    stpt=epochlocs1(i);
    end;
    
    seg=hensp1(strt:stpt);seg1=seg./max(seg);
    
    k=length(seg);
    for j=3:length(seg)
        
        if (seg(k)>seg(k-1) && seg(k-1)<seg(k-2) && seg1(k-1)<thresh)
         loc=k-1;
         val=seg(k-1);
         break
        else
        k=k-1; 
        loc=k-1;
        val=seg(k-1);
        end;
        
    end;
    if (length(seg)<3)
    loc=k;
    val=seg(loc);
    end;    
    pre_dip_loc(i)=epochlocs1(i)-(length(seg)-loc);
    pre_dip_val(i)=val;
 
end