function[mvn_feat]=Zero_Mean_Unit_Var_v2(featurevect,mean_vector,st_deviation)

%row: dimension; column: no of frames

[rsize,csize]=size(featurevect);

%mean_vector=mean(featurevect);%mean of feature vectors

% mean_repeat=repmat(mean_vector,rsize,1);
% 
% cms_featurevect=featurevect-mean_repeat;

%st_deviation=std(featurevect);

for i=1:rsize

mvn_feat(i,:)=(featurevect(i,:)-mean_vector)./st_deviation;

end

