function [ngdloc]=CorrectGCI(hensp1,ngdloc1)


ngdloc=ngdloc1;
 for l=1:length(ngdloc1)-1
strt=ngdloc1(l);
stpt=ngdloc1(l+1)-10;    
    if (strt>stpt)
    continue
    end
    if (strt<1)
      strt=1;     
    end;
    
    if(stpt>length(hensp1)) 
        stpt=length(hensp1);
    end;
    [m ind]=max(hensp1(strt:stpt));
   ngdloc(l)=strt+ind-1;    
end;
%ngdloc=unique(ngdloc);