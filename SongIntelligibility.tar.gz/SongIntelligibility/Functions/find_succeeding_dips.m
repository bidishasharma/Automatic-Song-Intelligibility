function [suc_dip_loc suc_dip_val]=find_succeeding_dips(epochlocs1,hensp1,thresh)

hensp1=hensp1./max(hensp1);
for i=1:length(epochlocs1)
    
    if (i==length(epochlocs1))
    strt=epochlocs1(i);
    stpt=length(hensp1)-2;
        
    else
        
    strt=epochlocs1(i);
    stpt=epochlocs1(i+1);

    end;
    
    seg=hensp1(strt:stpt);seg1=seg./max(seg);
    for j=1:length(seg)-2
        
        if (seg(j)>seg(j+1) && seg(j+1)<seg(j+2) && seg1(j+1)<thresh)
         loc=j+1;
         val=seg(j+1);
         break
        end;
        
    end;
    
    suc_dip_loc(i)=epochlocs1(i)+loc-1;
    suc_dip_val(i)=val;
 
end;