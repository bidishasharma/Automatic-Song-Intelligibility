
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%VOPTEST%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [MSAA1 MSMS1 SHE1]=VOPFeatures(data,sf,fsizems,fshiftms)


  out1 = data(:,1);
  out2=out1-mean(out1);
  out=out2/max(abs(out2));
%--------------------------------------------------------------------------
Fs=sf; LPFL=(20*Fs)/1000; LPOLN=(10*Fs)/1000; P=8; Npoints=(50*Fs)/1000;                                                                                                        % FOR HE MEANSMOOTH  
WL=(fsizems*Fs)/1000;  OL=(fshiftms*Fs)/1000;   NFFT=512;     NPEAKS=10;                              
Fmin=0;  Fmax=Fs/2;  NBANDS=18;  NORDER=1000; LPFFc=28; MWL=20; MOLN=1;                    
%%%%%%--------------------------------------------------------------------------
%LPR
[res1,LPCoeffs1] = LPresidual_v4(out,LPFL,LPOLN,P,1,1,0);
%--------------------------------------------------------------------------
%DFT,MS,SHE
[sumAmp1]=computesumdft(out,Fs,WL,OL,NFFT,NPEAKS);
[ms1,MS1]= modulationspectrum(out,Fmin,Fmax,Fs,NBANDS,NORDER,LPFFc,MWL,MOLN);
he1=abs(hilbert(res1))';
she1=meansmooth(he1,Npoints,0);
she1=she1-min(she1); 
SHE1=she1;%./max(abs(she1));
%--------------------------------------------------------------------------
AA11=repeatvalues(sumAmp1,OL);
AA1=[AA11 AA11(end).*ones(1,length(out)-length(AA11))];
% AA1=AA1-min(AA1);AA1=AA1./max(abs(AA1));
% MS1=MS1-min(MS1);MS1=MS1./max(abs(MS1));
%--------------------------------------------------------------------------
%MEAN SMOOTH
NMP=(50*Fs)/1000;
MSAA1=meansmooth(AA1,NMP,0);       %DFT
MSMS1=meansmooth(MS1,NMP,0);       %Modulation Spectrum
SHE1=meansmooth(SHE1,NMP,0);    %Smoothed Hilbert Envelope
% ZTL1= ztl_evidence (out,sf);
% ZTL1=repeatvalues(sumAmp1,OL);
% ZTL1=smooth(ZTL1,800);
% %ZTL1=ZTL1';
% ZTL1=[ZTL1 ZTL1(end).*ones(1,length(out)-length(ZTL1))];
% ZTL1=ZTL1-min(ZTL1);ZTL1=ZTL1./max(abs(ZTL1));
% %[ZTL1]= repeat_valuesv2(ZTL1,length(out));
% 
% % figure;
% % subplot(5,1,1);plot(out);title('speech signal');
% % subplot(5,1,2);plot(MSAA1);title('DFT evidence');
% % subplot(5,1,3);plot(MSMS1);title('Modulation Spectrum');
% % subplot(5,1,4);plot(SHE1);title('Smoothed Hilbert Envelope');
% % subplot(5,1,5);plot(ZTL1);title('ZTL evidence');
% 
% 
% 
% %--------------------------------------------------------------------------
% %FIND THE SLOPE
% MD1=diff(MSAA1);MD1=MD1./max(abs(MD1));
% MD2=diff(MSMS1);MD2=MD2./max(abs(MD2));
% MD3=diff(SHE1); MD3=MD3./max(abs(MD3));
% MD4=diff(ZTL1); MD4=MD4./max(abs(MD4));
% %--------------------------------------------------------------------------
% %MEDIAN FILTERING TO REMOVE THE SPIKES
% D1=medfilt1(MD1,5);
% D2=medfilt1(MD2,5);
% D3=medfilt1(MD3,5);
% D4=medfilt1(MD4,5);
% %--------------------------------------------------------------------------
% %FIND THE POS ZC  (PEAKS)
% plotflag=0;
% [PN1,SLP1]=findpostonegzc_V3(D1,2,40);
% In1=find(PN1==1);
% [Ind11,Ind13,Ind12,Me1]=Tempfun_V6(MSAA1,SLP1,In1,1,0.5*mean(MSAA1),400,plotflag);
% 
% [PN2,SLP2]=findpostonegzc_V3(D2,2,40);
% In2=find(PN2==1);
% [Ind21,Ind23,Ind22,Me2]=Tempfun_V6(MSMS1,SLP2,In2,1,0.7*mean(MS1),400,plotflag);
% 
% [PN3,SLP3]=findpostonegzc_V3(D3,2,40);
% In3=find(PN3==1);
% [Ind31,Ind33,Ind32,Me3]=Tempfun_V6(SHE1,SLP3,In3,1,0.9*mean(SHE1),400,plotflag);
% 
% 
% [PN4,SLP4]=findpostonegzc_V3(D4,2,40);
% In4=find(PN4==1);
% [Ind41,Ind43,Ind42,Me4]=Tempfun_V6(ZTL1',SLP4,In4,1,0.5*mean(ZTL1),400,plotflag);
% %--------------------------------------------------------------------------
% %FIND THE NEG ZC (VALLEY)
% NP1=findnegtoposzc(D1,5);Ind1=find(NP1==1);
% NP2=findnegtoposzc(D2,5);Ind2=find(NP2==1);
% NP3=findnegtoposzc(D3,5);Ind3=find(NP3==1);
% NP4=findnegtoposzc(D4,5);Ind4=find(NP4==1);
% %--------------------------------------------------------------------------
% %ENHANCE THE VALUES
% %[EnhancedValues,Index]=regions_V2(SIGNAL, PEAKS, VALLEYS, DIST B/W PEAKS&VALLEYS)
% [MSAAR,Index1r]=regions_V2(MSAA1,Ind12,Ind1,200);       
% [MSMSR,Index2r]=regions_V2(MSMS1,Ind22,Ind2,0); %% give the energy value here
% [SHER,Index3r]=regions_V2(SHE1,Ind32,Ind3,100);
% [ZTLR,Index4r]=regions_V2(ZTL1,Ind42,Ind4,200);


% figure;
% subplot(5,1,1);plot(out);title('speech signal');
% subplot(5,1,2);plot(MSAAR);title('DFT evidence');
% subplot(5,1,3);plot(MSMSR);title('Modulation Spectrum');
% subplot(5,1,4);plot(SHER);title('Smoothed Hilbert Envelope');
% subplot(5,1,5);plot(ZTLR);title('ZTL evidence');

%--------------------------------------------------------------------------
%--------VOPEVIDENCES-----------------------------------------------------------------
%-----------windowing-------------
% [G,Gd]= gausswin1(801,200);
% nc=conv(MSMSR,Gd);
% n1=nc(401:length(nc)-400);
% n1=n1/max(abs(n1));
% nc1=conv(MSAAR,Gd);
% n2=nc1(401:length(nc1)-400);
% n2=n2/max(abs(n2));
% nc3=conv(SHER,Gd);
% n3=nc3(401:length(nc3)-400);
% n3=n3/max(abs(n3));
% 
% nc4=conv(ZTLR,Gd);
% n4=nc4(401:length(nc4)-400);
% n4=n4/max(abs(n4));
% [n4]= repeat_valuesv2(n4,length(n1));
% 
% N1=n1+n2+n3+n4;    %%%% Combining existing and sonority evidence
% N1=N1/max(abs(N1));  
% 
% N2=n1+n2+n3 ;  %%%Only existing evidences
% N2=N2/max(abs(N2));
% 
% N3=n4;         %%%%%%%%%%%only sonority evidence
% N3=N3/max(abs(N3));
% 


% [VOP_ref VEP_ref]= find_timit_vop (labfile);
% 
% 
% 
% th_peak=.5;
% th_p2d=1;
% %th_dist=1*sf*10^-3;
% th_dist=0;
% 
% N1_new= change_rangeof_values(N1,0,1);
% [VOP1] = find_prominent_peak (N1_new,th_peak,th_p2d,th_dist);
% 
% N2_new= change_rangeof_values(N2,0,1);
% [VOP2] = find_prominent_peak (N2_new,th_peak,th_p2d,th_dist);
% 
% N3_new= change_rangeof_values(N3,0,1);
% [VOP3] = find_prominent_peak (N3_new,th_peak,th_p2d,th_dist);