function [NormAutoCorr,Pitch_Contour,Peaks,pitch_period]=norm_auto(data,Fs,Frame_Size,Frame_Shift)
out1 = data;
out2=out1-mean(out1);
out=out2/max(abs(out2));
speechsignal=out';
Nframesize	= round(Frame_Size * Fs / 1000);
% Nframeshift =1;
Nframeshift	= round(Frame_Shift * Fs / 1000);
Nspeech 	= length(speechsignal);
Total_Num_frames=floor((Nspeech-Nframesize)/Nframeshift)+1;
j=0;
for i = 1:Nframeshift:Nspeech-Nframesize
    j=j+1;
    SpFrm	= speechsignal(i:i+Nframesize-1);
    a= xcorr(SpFrm,'coeff');
    NormAutoCorr(j,:)=a(1,[ceil(length(a)/2):length(a)]);
end
pitch_period=0;j=0;
for i=1:Nframeshift:Nspeech-Nframesize
    j=j+1;
    norm_auto_val=NormAutoCorr(j,[17:end]);
    [FL,Amp]=findpeaks_V3(norm_auto_val);
    [val_peak in_val]=max(Amp);
    Amp(1)=val_peak;
    FL(1)=FL(in_val);
    Peaks(j)=Amp(1);
    pitch_period(j)=(FL(1)+16)/Fs;
    Pitch_Contour(j)=1/pitch_period(j);
end

end

