

function [source_feat2,final_feat1]=repeat_framewise(y,source_feat1,epochlocs1,fshift,fsize)
%%%source_feat1--> Input feature; rows: no of epochs,columns: feature dimension

    source_feat2=zeros(1,length(y));
    
   
    for i=1:length(epochlocs1)-1
        
       source_feat2(epochlocs1(i):epochlocs1(i+1)-1)= source_feat1(i);
        
    end
    
    cnt=0;
    for j=1:fshift:length(y)-fsize
    strt=j;
    stpt=j+fsize-1;
    cnt=cnt+1;
    clear tmp;
    temp=source_feat2(strt:stpt);
    final_feat1(cnt)=mean(temp);
    end