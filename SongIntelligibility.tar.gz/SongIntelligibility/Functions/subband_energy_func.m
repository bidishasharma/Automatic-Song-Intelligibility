function [En] = subband_energy_func(y,winlength,winshift,band_no);
m=ceil(log2(winlength));
N=2^m; %%%%%how many point fft
count=1;

for j=1:winshift:length(y)-winlength
    
    count=count+1;
    tmp=y(round(j):round(j+winlength));
    
    fft_out=fft(tmp,N);
    fft_out=fft_out(1:round(winlength));
    
    %%%%divide into 4 bands%%%%%%%%%%
    
    bands=length(fft_out)/band_no;
    
    for i=1:band_no
       
        strt=(i-1)*bands+1; stp=(i-1)*bands+bands;
        
        retain_idx=strt:stp;
        
        temp=zeros(1,winlength);
        
        temp(round(retain_idx))=fft_out(round(retain_idx));
        
        ifft_out(i,:)=ifft(temp,N);
        
        En(count,i)=sum(abs(ifft_out(i,:)).*abs(ifft_out(i,:))); %%%%%%corresponds to jth frame of ith subband       
        
    end;    
end;