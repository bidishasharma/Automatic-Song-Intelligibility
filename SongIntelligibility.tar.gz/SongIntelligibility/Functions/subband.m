% clc;
% clear all;
% close all;
% 
% [y,fs]=wavread('/home/queen/PHD/syll_rate/Test_data/kora_hoise.wav');
% 
% y=y(:,1);

function [corr1 corr2]=subband(y,fs,winlength,winshift)

band_no=4;
X = subband_energy_func(y,winlength,winshift,band_no);
 

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%Gaussian window weighting%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 
 K=10;
 winlen=K;
 win_shift=1;
 window=gausswin(K,1/1.2);
 
  temp_corr_out=[];
  
  
 for i=1:band_no
 
     tmp=X(:,i);
     win_out=zeros(1,length(tmp));
     win=zeros(1,length(tmp));
     L=length(tmp);
     div=floor(length(tmp)/win_shift);
     winlen=K;
      win_shift=1;
     window=gausswin(K,1/1.2);
     
     
     for j=1:L-winlen
        
         strt=(j-1)*win_shift+1;
         stp=strt+winlen-1;
         
         if(stp>L)
             
             diff=stp-L;
             
             tmp=[tmp;zeros(1,diff)];
%              stp=length(tmp)
%              diff=stp-strt+1;
%              window=window(1:diff);
             
         end;
     
       win2=tmp(strt:stp).*window;
       win_vector(j,:)=win2;
       
         
%          win(strt:stp)=tmp(strt:stp).*window;
%          
%          win_out=win_out+win;
%          
%          win=zeros(1,L);
%          
         
     end;
     
     temp_corr=[];
     sz=size(win_vector);
     
     for q=1:sz(1)
         tmp1=win_vector(q,:);
         tmp3=0;
         
         for r=1:K-2
             tmp2=0;
             
             for p=r+1:K-1
                 
                 tmp2=tmp2+tmp1(p)*tmp1(r);
                 
             end;
             
             tmp3=tmp3+tmp2;
             
         end;
         
  
        % temp_corr
         temp_corr=[temp_corr tmp3];
         
     end
     
     temp_corr_out=[temp_corr_out;  temp_corr];
     
     cof=1/(2*K*(K+1));
     temp_corr_out=temp_corr_out./cof;
     temp_corr_out=sqrt(temp_corr_out);
     
%      win_out(stp+1:end)=tmp(stp+1:end);
%     
%      tmp_wghted(i,:)=win_out;
     
    
 end;
 
 clear tmp;clear win;clear win_out;
 
 
 
 
 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%find subband correlation%%%%%%%%%%%%%%%%%%%%
 
 corr1 = subband_corr(y,temp_corr_out,band_no,winshift); %%%%after gaussian weighting and temporall correlation
 
 
 corr2 = subband_corr(y,X',band_no,winshift);%%%%%%%%directly sub-band energy vector
 
 %%%%%%%%%%%%%%%%%%smoothing%%%%%%%%%%%%%%%%%%%%%
 
 
 Es(1)=corr2 (1);Es(2)=corr2 (2);
for i=3:length(corr2 )-2
    
    Es(i)=(corr2 (i-2)+corr2 (i-1)+corr2 (i)+corr2 (i+1)+corr2 (i+2))/5;
    
end;
Es(length(corr2 )-1)=corr2 (length(corr2 )-1);Es(length(corr2 ))=corr2 (length(corr2 ));

Es=Es./max(Es);
 
 

%%%%%%%%%%%%%Peak counting of corr1%%%%%%%%%%%%%%%%%%%%

[index, peak_en] = find_peaks(corr1);
peaks=zeros(1,length(corr1));peaks(index)=1;
 
%  N=band_no;
%  
%  
%  
%  M=N*(N-1)/2;
%  
%  Z=temp_corr_out';
%  
%  for n=1:(length(y)/winshift)-1
%  
%  
%  sum2=0;
%  for i=1:N-1
%      
%      
%      sum1=0;
%      for j=i+1:N
%          
%          sum1=sum1+X(n,i)*X(n,j);
%          
%      end;
%      
%      sum2=sum2+sum1;
%      
%  end;
%      
%  corr(n)=sum2
%  
%          
%  end;
 
 %%%%%%%%plot figure %%%%%%%%%%%%%%%%%%%%%%%%%%
 
%  figure;
%  
%  ax(1)=subplot(4,1,1);plot(y);hold on; stem(1:length(y)/length(corr1):length(y),peaks,'r');
%  ax(2)=subplot(4,1,2);plot(1:length(y)/length(corr1):length(y),corr1); 
%   ax(3)=subplot(4,1,3);plot(1:length(y)/length(corr2):length(y),corr2);
%   ax(4)=subplot(4,1,4);plot(1:length(y)/length(Es):length(y),Es);linkaxes(ax,'x');
 
 
 
 
    
    
    