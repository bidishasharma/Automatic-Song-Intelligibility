function [index, peak_en] = find_peaks(Ep)

syll=0;
index=[];
peak_en=[];

for i=1:length(Ep)-2
    tmp1=Ep(i)-Ep(i+1);tmp2=Ep(i+1)-Ep(i+2);
    if(tmp1<0 && tmp2>0 )
        
        index=[index,i+1];
        peak_en=[peak_en Ep(i+1)];
        syll=syll+1;
    end;

end;