%% Reading from file
function [First_Peaks,PSR_inter]=SpectralFeatures(sp1sig,fs,Frame_Size,Frame_Shift)

%%PSR_inter--> Peak_side_lobe_ratio
%%st_energy--> Short term energy
%%speckur--> Spectral Kurtosis
%%specdec--> Spectral Decrease
%%specton--> SpectralTonalPowerRatio
%%First_Peaks--> Normalized ACR peaks
%%
%%

%[sp1sig,fs1]=audioread('E:\vmware\DATA\FullDataset\excerpt1_Sentimental Journey.wav');
% addpath('/home/nus/PHDWorkspace/BANRI/norM_AUTO');
% addpath('/home/nus/PHDWorkspace/BANRI/norM_AUTO/ACA-Code-master');
sp1sig=sp1sig(:,1);
sp1sig=sp1sig./(1.01*max(abs(sp1sig)));
% sp1sig=resample(sp1sig,8000,fs1);
% fs=8000;   

%% compute LP residual and ILPR and ZFFS

% lporder=fs/1000+4;
% 
% ressp=LPres(sp1sig,fs,winlen,winshift,lporder,1);
% ressp=ressp./(1.01*max(abs(ressp)));
% 
% ressp1=ILPR(sp1sig,fs,winlen,winshift,lporder,1);
% ressp1=ressp1./(1.01*max(abs(ressp1)));
% 
% hensp=HilbertEnv(ressp,fs,1);
% hensp=hensp./(max(abs(hensp)));
% 
% hensp1=HilbertEnv(ressp1,fs,1);
% hensp1=hensp1./(max(abs(hensp1)));

%[zsp1,epstrsp1,vgclocssp1,vf0sp1]=zff_computefn(sp1sig,fs);


%% ZFF ENERGY
% Frame_Size=winlen; Frame_Shift=winshift;
% [st_energy]=short_term_energy(zsp1,fs,Frame_Size,Frame_Shift);
% Nframeshift	= round(Frame_Shift * fs / 1000);
% ST_ENERGY=repeatvalues(st_energy,Nframeshift);
% st_energy=[ST_ENERGY ST_ENERGY(end).*ones(1,length(sp1sig)-length(ST_ENERGY))];
% st_energy=st_energy-min(st_energy);st_energy=st_energy./max(abs(st_energy));
% NMM=(1000*fs)/1000;
% [mean_ENVAL]=meansmooth(st_energy,NMM,0);
% % NMP=(3*fs)/1000;
% % meanssmooth_he=meansmooth(hensp1,NMP,0); 
% theta=0.2;
% tau=0.001;
% alpha=0.00;
% non_linear_zffenergy=compute_weightfn(mean_ENVAL,theta,tau,alpha);

%% PSR

Frame_Size=20; Frame_Shift=10;
[index_peak_arr,hensp1,peak_val_arr,PSR_inter]=peak_to_side_var(sp1sig,fs,Frame_Size,Frame_Shift);
% NMP=(1000*fs)/1000;
% % [means_PSR]=meansmooth(PSR_inter,NMP,0);
% [var_PSR]=variancesmooth(PSR_inter,NMP);

%% NORM AUTO
Frame_Size=20; Frame_Shift=10;
[AutoCorr,Pitch_Contour,First_Peaks,pitch_period]=norm_auto(sp1sig,fs,Frame_Size,Frame_Shift);
Nframeshift	= round(Frame_Shift * fs / 1000);
first_peaks=repeatvalues(First_Peaks,Nframeshift);
First_Peaks=[first_peaks first_peaks(end).*ones(1,length(sp1sig)-length(first_peaks))];
%First_Peaks=First_Peaks-min(First_Peaks);First_Peaks=First_Peaks./max(abs(First_Peaks));
 NMP=(1000*fs)/1000;
% means_norm=meansmooth(First_Peaks,NMP,0); 

 %% Spectral Based
% Frame_Size=20; Frame_Shift=10;
% Nframesize=round(Frame_Size * fs / 1000);
% Nframeshift	= round(Frame_Shift * fs / 1000);
% afWindow=rectwin(Nframesize);
% cFeatureName='SpectralDecrease'
% [specdec2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% specdec1=repeatvalues(specdec2,Nframeshift);
% specdec=[specdec1 specdec1(end).*ones(1,length(sp1sig)-length(specdec1))];
% %specdec=specdec-min(specdec);specdec=specdec./max(abs(specdec));
% NMM=(1000*fs)/1000;
% [Var_specdec]=variancesmooth(specdec,NMM);
 
% cFeatureName='SpectralKurtosis'
% [speckur2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% speckur1=repeatvalues(speckur2,Nframeshift);
% speckur=[speckur1 speckur1(end).*ones(1,length(sp1sig)-length(speckur1))];
% %speckur=speckur-min(speckur);speckur=speckur./max(abs(speckur));
% NMM=(1000*fs)/1000;
% [Var_speckur]=variancesmooth(speckur,NMM);

% cFeatureName='SpectralTonalPowerRatio'
% [specton2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% specton1=repeatvalues(specton2,Nframeshift);
% specton=[specton1 specton1(end).*ones(1,length(sp1sig)-length(specton1))];
% %specton=specton-min(specton);specton=specton./max(abs(specton));
% NMM=(1000*fs)/1000;
% [Var_specton]=variancesmooth(specton,NMM);
% 
% cFeatureName='SpectralSlope';
% [specslope2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% specslope1=repeatvalues(specslope2,Nframeshift);
% specslope=[specslope1 specslope1(end).*ones(1,length(sp1sig)-length(specslope1))];
% %specslope=specslope-min(specslope);specslope=specslope./max(abs(specslope));
% NMM=(1000*fs)/1000;
% [Var_specslope]=variancesmooth(specslope,NMM);


% cFeatureName='SpectralCentroid';
% [SpectralCentroid,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% SpectralCentroid1=repeatvalues(SpectralCentroid,Nframeshift);
% SpectralCentroid=[SpectralCentroid1 SpectralCentroid1(end).*ones(1,length(sp1sig)-length(SpectralCentroid1))];
%SpectralCentroid=SpectralCentroid-min(SpectralCentroid);SpectralCentroid=SpectralCentroid./max(abs(SpectralCentroid));


% 
% cFeatureName='SpectralFlatness';
% [Feat2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% Feat1=repeatvalues(Feat2,Nframeshift);
% Feat=[Feat1 Feat1(end).*ones(1,length(sp1sig)-length(Feat1))];
% Feat=Feat-min(Feat);Feat=Feat./max(abs(Feat));
% SpectralFlatness=Feat;
% clear Feat; clear Feat2; clear Feat1;

% cFeatureName='SpectralRolloff';
% [Feat2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% Feat1=repeatvalues(Feat2,Nframeshift);
% Feat=[Feat1 Feat1(end).*ones(1,length(sp1sig)-length(Feat1))];
% %Feat=Feat-min(Feat);Feat=Feat./max(abs(Feat));
% SpectralRolloff=Feat;
% clear Feat; clear Feat2; clear Feat1;


% cFeatureName='SpectralSkewness';
% [Feat2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% Feat1=repeatvalues(Feat2,Nframeshift);
% Feat=[Feat1 Feat1(end).*ones(1,length(sp1sig)-length(Feat1))];
% %Feat=Feat-min(Feat);Feat=Feat./max(abs(Feat));
% SpectralSkewness=Feat;
% clear Feat; clear Feat2; clear Feat1;

% cFeatureName='SpectralSpread';
% [Feat2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% Feat1=repeatvalues(Feat2,Nframeshift);
% Feat=[Feat1 Feat1(end).*ones(1,length(sp1sig)-length(Feat1))];
% %Feat=Feat-min(Feat);Feat=Feat./max(abs(Feat));
% SpectralSpread=Feat;
% clear Feat; clear Feat2; clear Feat1;


% cFeatureName='TimeMaxAcf';
% [Feat2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% Feat1=repeatvalues(Feat2,Nframeshift);
% Feat=[Feat1 Feat1(end).*ones(1,length(sp1sig)-length(Feat1))];
% Feat=Feat-min(Feat);Feat=Feat./max(abs(Feat));
% TimeMaxAcf=Feat;
% clear Feat; clear Feat2; clear Feat1;
% 
% 
% 
% cFeatureName='TimePredictivityRatio';
% [Feat2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% Feat1=repeatvalues(Feat2,Nframeshift);
% Feat=[Feat1 Feat1(end).*ones(1,length(sp1sig)-length(Feat1))];
% Feat=Feat-min(Feat);Feat=Feat./max(abs(Feat));
% TimePredictivityRatio=Feat;
% clear Feat; clear Feat2; clear Feat1;
% 
% 
% cFeatureName='TimeStd';
% [Feat2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% Feat1=repeatvalues(Feat2,Nframeshift);
% Feat=[Feat1 Feat1(end).*ones(1,length(sp1sig)-length(Feat1))];
% Feat=Feat-min(Feat);Feat=Feat./max(abs(Feat));
% TimeStd=Feat;
% clear Feat; clear Feat2; clear Feat1;
% 
% 
% cFeatureName='TimeZeroCrossingRate';
% [Feat2,t] = ComputeFeature(cFeatureName,sp1sig,fs,afWindow,Nframesize,Nframeshift);
% Feat1=repeatvalues(Feat2,Nframeshift);
% Feat=[Feat1 Feat1(end).*ones(1,length(sp1sig)-length(Feat1))];
% Feat=Feat-min(Feat);Feat=Feat./max(abs(Feat));
% TimeZeroCrossingRate=Feat;
% clear Feat; clear Feat2; clear Feat1

