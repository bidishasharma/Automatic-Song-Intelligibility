function [AllFeat1,VUVLabelFrame]=FindSpeechSpecificFeatures(s1,s2,fs,winlen,winshift)

fsizems=(winlen*1000)/fs;fshiftms=(winshift*1000)/fs;
[sp1sig1,zsp1,epstrsp1,vf0sp1,vgclocssp1,hensp1]=PitchContour(s2,fs,fsizems,fshiftms);
[ngdloc1]=CorrectGCI(hensp1,vgclocssp1);
ngdloc2=ngdloc1.*round(fs/8000);
vgclocssp1=vgclocssp1.*round(fs/8000);

UnvoicedThres=30*10^-3*fs;%%%in milisecond
indx1=find(diff(ngdloc2)>UnvoicedThres);
indx11=ngdloc2(indx1);
VoiceSegment=ones(1,length(s1));
for ii=1:length(indx11)
VoiceSegment(indx11(ii):ngdloc2(indx1(ii)+1))=0;
end
VoiceSegmentFrame=enframe(VoiceSegment,winlen,winshift);
VUVLabelFrame=mode(VoiceSegmentFrame,2);

%%
%%Suprasegmental Feature
[SupraFeat1] = SuprasgmentalFeat(s1,fs,ngdloc2);
[~,PitchFeat]=repeat_framewise(s2,vf0sp1,vgclocssp1,winshift,winlen);
len1=length(PitchFeat);
[SupraFeat] = NormalizeLen(SupraFeat1,len1); 


%%
%%Spectral Slope 
[AllSlope1,~]=FindSpectralSlope(s1,fs,fsizems,fshiftms);
[SpectralSlope]=NormalizeLen(AllSlope1,len1); 

%%
%%Subband Correlation
[~,corr2]=subband(s1,fs,winlen,winshift);
[SubbandCorr]=NormalizeLen(corr2,len1); 

%%
%%henv slope
lporder=fs/1000+4;
ressp1=LPres(s1,fs,fsizems,fshiftms,lporder,0);
hensp1=HilbertEnv(ressp1,fs,1);
[slope1]= henv_slope_function(s1,fs,hensp1,ngdloc2');
[~,HenvSlope]=repeat_framewise(s1,slope1,ngdloc2,winshift,winlen);
[HenvSlope]=NormalizeLen(HenvSlope,len1); 

%%
%%Jitter Shimmer
[jitterabs1,shimmerabs1,~,eplocs1]=jittershimmerfeatures(s1,fs,5,fsizems,fshiftms);
[~,jitterabs11]=repeat_framewise(s1,jitterabs1,eplocs1(1:length(jitterabs1)),winshift,winlen);
[~,shimmerabs11]=repeat_framewise(s1,shimmerabs1,eplocs1(1:length(shimmerabs1)),winshift,winlen);
[jitterabs11]=NormalizeLen(jitterabs11,len1);  
[shimmerabs11]=NormalizeLen(shimmerabs11,len1); 

%VOP Features
[MSAA1,MSMS1,SHE1]=VOPFeatures(s1,fs,fsizems,fshiftms);
MSAA11=enframe(MSAA1,winlen,winshift);MSAA11=mean(MSAA11,2);
[MSAA11]=NormalizeLen(MSAA11',len1); 

MSMS11=enframe(MSMS1,winlen,winshift);MSMS11=mean(MSMS11,2);
[MSMS11]=NormalizeLen(MSMS11',len1); 

SHE11=enframe(SHE1,winlen,winshift);SHE11=mean(SHE11,2);
[SHE11]=NormalizeLen(SHE11',len1); 

%Spectral Features
[First_Peaks,PSR_inter]=SpectralFeatures(s1,fs,fsizems,fshiftms);
PSR_inter11=enframe(PSR_inter,winlen,winshift);PSR_inter11=mean(PSR_inter11,2);
First_Peaks11=enframe(First_Peaks,winlen,winshift);First_Peaks11=mean(First_Peaks11,2);
[PSR_inter11]=NormalizeLen(PSR_inter11',len1); 
[First_Peaks11]=NormalizeLen(First_Peaks11',len1); 

AllFeat1=[SupraFeat;PSR_inter11;First_Peaks11;MSAA11;MSMS11;SHE11;jitterabs11;shimmerabs11;HenvSlope;SubbandCorr;SpectralSlope;PitchFeat];

