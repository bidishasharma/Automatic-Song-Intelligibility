
function [All_H1]= find_spectrum3(LPCs1,fs1)


S1=size( LPCs1);
for i=1:S1(1)
    
[H1,F1] = freqz(1,LPCs1(i,:),(2^10)+1, fs1);
 H1=H1./max(H1);
%  H1=20*log10(abs(H1));
 %H1=H1-min(H1);   
 All_H1(:,i)=H1;
 
end;
 