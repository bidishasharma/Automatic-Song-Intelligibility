
function [corr]= subband_corr(y,temp_corr_out,band_no,winshift);


N=band_no;
 
 
 
 M=N*(N-1)/2;
 
 Z=temp_corr_out';
 sz=size(temp_corr_out);
 %for n=1:(length(y)/winshift)-1
 
 for n=1:sz(2)
 
 
 sum2=0;
 for i=1:N-1
     
     
     sum1=0;
     for j=i+1:N
         
         sum1=sum1+Z(n,i)*Z(n,j);
         
     end;
     
     sum2=sum2+sum1;
     
 end;
     
 corr(n)=sum2;
 
         
 end;