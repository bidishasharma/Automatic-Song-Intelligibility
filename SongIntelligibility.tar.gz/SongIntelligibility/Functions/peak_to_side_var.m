% %%%%% CLEAR ALL %%%%%%
function [index_peak_arr,hensp1,peak_val_arr,Peak_side_lobe_inter]=peak_to_side_var(data,Fs,framesize,frameshift)


%%%%%%%%% LPRES AND HENV %%%%%%%%%%%%%%%%%%%%%%%
out1 = data;
out2=out1-mean(out1);
out=out2/max(abs(out2));
speechsignal=out;
lporder=Fs/1000+4;
preemp=0;
[ressp1] = LPres(speechsignal,Fs,framesize,frameshift,lporder,preemp);
hensp1=HilbertEnv(ressp1,Fs,1);
[zsp1,epstrsp1,vgclocssp1,vf0sp1]=zff_computefn(speechsignal,Fs);
hensp1=hensp1/(1.05*max(hensp1));
Frame_Size=framesize;
Frame_Shift=frameshift;
Nframesize	= round(Frame_Size * Fs / 1000);
Nframeshift	= round(Frame_Shift * Fs / 1000);
Nspeech 	= length(speechsignal);
Total_Num_frames=floor((Nspeech-Nframesize)/Nframeshift)+1;
j=0;
hensp1=hensp1/(1.05*max(hensp1));
epstrsp1=epstrsp1/(1.05*max(epstrsp1));
ff=find(epstrsp1>0.01);
ff=ff';
frame_epoch_length=12; %%(12/8000=1.5ms on either side) %% window for searching peaks around epoch locations (25 samples)
frame_side_lobe=30;   %% (30/8000=3.75ms on either side) %% window for computing side lobe variance (20 samples)
for i=1:length(ff)
    epoch_loc=ff(1,i);
    frame_epoch_length_left=(epoch_loc)-frame_epoch_length;
    if(frame_epoch_length_left<1)
        frame_epoch_length_left=1;
    end    
    frame_epoch_length_right=(epoch_loc)+frame_epoch_length;
    [FL,Amp]=findpeaks_V3(hensp1(frame_epoch_length_left:frame_epoch_length_right));
      [peak_val,ind_loc]=max(Amp);
      peak_loc=FL(ind_loc);
      if (peak_val>=0.00)
      if(peak_loc>=(frame_epoch_length+1))
          act_peak_loc=(peak_loc-(frame_epoch_length+1))+epoch_loc;
      else
          act_peak_loc=epoch_loc-((frame_epoch_length+1)-peak_loc);
      end
      index_peak=act_peak_loc;
      peak_val_arr(1,i)=peak_val;
      index_peak_arr(1,i)=index_peak;
      s_left=(index_peak-1)-frame_side_lobe;
      s_right=(index_peak+1)+frame_side_lobe;
      if(s_left<=0)
      Peak_side_lobe_ratio(1,i)=0;
      continue;
      elseif(s_right>length(hensp1))
      Peak_side_lobe_ratio(1,i)=0;
      continue;
      else
      frame_left=hensp1(s_left:index_peak-1);
      frame_right=hensp1(index_peak+1:s_right); 
      side_lobe=[frame_left,frame_right];
      side_lobe_var=var(side_lobe,1);
  
      if (side_lobe_var==0)
          Peak_side_lobe_ratio(1,i)=peak_val;
          continue;
      end
      Peak_side_lobe_ratio(1,i)=peak_val./side_lobe_var;
      end
      else
          Peak_side_lobe_ratio(1,i)=0;
      end
end
Peak_side_lobe=Peak_side_lobe_ratio;%./max(Peak_side_lobe_ratio);

%epoch index 
 %psr vals
 NegIndx=find(index_peak_arr<1);
 index_peak_arr(NegIndx)=[];
mm(1:index_peak_arr(1))=Peak_side_lobe(1); %inter_psr
j=2;
for i=index_peak_arr(1)+1:length(hensp1)
    if (i>index_peak_arr(end))
       mm(i)=Peak_side_lobe(end);
       continue;
    end
    if(i>=index_peak_arr(j))
        mm(i)=Peak_side_lobe(j);
        j=j+1;
        continue;
    else
       mm(i)=Peak_side_lobe(j);
    end   
end



Peak_side_lobe_inter=mm;

end



% size(means)
% size(xin_mean)
% figure;
% plot(xin_mean(1:length(means)),means);

% tt=0:0.01:1;
% figure(), hist(Peak_side_lobe,tt)



