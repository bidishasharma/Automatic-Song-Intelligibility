clc;
clear all;
close all;

addpath('./Functions');
addpath('./libsvm-3.24');
addpath('./SoundZone_Tools-master');
addpath('./ZTLEvidence');
addpath('./libsvm-3.24/matlab');%%Libsvm Path
addpath('/home/nus/BidishaResearch/STS/voicebox/');%%Change to your local voicebox path
ModelPath='./SVMModel/Model.mat';%%Pretrained SVM Model (Request to author s.bidisha@nus.edu.sg for the pretrained model)


InputWav='./InputWav/excerpt1_Asa_Fire_on_the_MountainMixed.wav';
InputWavExtracted='./InputWav/excerpt1_Asa_Fire_on_the_MountainVocal.wav';



[y1,fs1]=audioread(InputWav);
s1=resample(y1(:,1),16000,fs1);
fs=16000;                                % Sampling frequency (Hz)
s1 = s1./max(abs(s1));  


[y2,fs2]=audioread(InputWavExtracted);
s2=resample(y2(:,1),16000,fs2);
fs=16000;                                % Sampling frequency (Hz)
s2 = s2./max(abs(s2));
s1=s1(1:length(s2));

winlen=25*10^-3*fs;
winshift=5*10^-3*fs;

[VocalFeatues,VUVLabelFrame]=FindSpeechSpecificFeatures(s1,s2,fs,winlen,winshift);
len=length(VocalFeatues);

s2=s2(1:length(s1));
[d,dFrame] = StoiModified(s1, s2, fs);
[STOIDist11]=NormalizeLen(dFrame,len); 
VocalFeatues=[VocalFeatues;STOIDist11];

VoicedFrames=find(VUVLabelFrame==1);  
VoicedVocalFeatues=VocalFeatues(:,VoicedFrames); %%Voiced Vocal Features

[MFCCs] = ExtractFeaturesMFCCs(InputWav,1102,220);
MFCCs=MFCCs(1:length(VocalFeatues),:);
VoicedMFCCs=MFCCs(VoicedFrames,:); %%Voiced MFCCs Features

CombFeatures=[VoicedVocalFeatues;VoicedMFCCs'];%%Combined Features
IndxInf=find(isinf(CombFeatures)==1);
IndxNan=find(isnan(CombFeatures)==1);
CombFeatures(IndxInf)=[];
CombFeatures(IndxNan)=[];

load(ModelPath);%%Load SVM Model
[mvn_featTest]=Zero_Mean_Unit_Var_Test(CombFeatures',mean_vector,st_deviation);
mvn_featTest=mvn_featTest';
AllLabelsTest=repmat(0.5,1,length(mvn_featTest));


[y_hat1, Acc1, projection1] = svmpredict(AllLabelsTest', mvn_featTest', model);

prob=y_hat1;
IntelligibilityScore=mean(prob)
