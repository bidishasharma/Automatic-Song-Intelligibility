function [spectral_energy spectral_energy1 formant1 formant2 formant3 band_energy]= main_prog(s, Framesize, fs)
x=s;
s1=s;

%% MAGNITUDE SPECTRUM

spec_s=fft(s, 8000);
mag_spec_s=abs(spec_s);


%% HDNGD COMPUTATION

%x=x(7044:(7044+Framesize*.001*fs-1));% 7044, 7468
%x=x(7205:(7205+Framesize*.001*fs-1));
%x=x(8952:(8952+Framesize*.001*fs-1));% 7044, 7468
nfft = 8000;
nwin = Framesize*.001*fs;
PLOTFLAG = 0;

[HDNGD,f,dngd,ngd,mag,hgd,dgd,gd,w] = ztl(x,fs,nfft,nwin,PLOTFLAG);

%spectral_energy =  sum(HDNGD(200:2000).*HDNGD(200:2000));
%figure;
%subplot(211);plot(x);
%subplot(212);
% plot(hngd);
% 
% figure;plot(diff(hngd));grid on;

%% LARGEST PEAK FREQ

%[peak peak_freq] = max(HDNGD(1:4000));

[peak_mag peak_freq] = max(mag_spec_s(1:4000));

[peak_hdngd peak_freq] = max(HDNGD(1:4000));

%% NORMALIZATION

HDNGD = (HDNGD/peak_hdngd)*peak_mag;

%% SPECTRAL ENERGY CALCULATION

%spectral_energy =  sum(dd_num_gpdl(1:2500).*dd_num_gpdl(1:2500));

spectral_energy =  sum(HDNGD(1:2500).*HDNGD(1:2500));

mag_spec_s=abs(fft(s1, 8000));

spectral_energy1 =  sum(mag_spec_s(1:2500).*mag_spec_s(1:2500));



%% FORMANTS

formant(1) = 0;
formant(2) = 0;
formant(3) = 0;

formant_count = 1;

HDNGD_diff = diff(HDNGD);
% 
for i=2:fs/2
    
    if HDNGD_diff(i-1) > 0
        
        if HDNGD_diff(i) < 0
            
            formant(formant_count) = i;
            
            formant_count = formant_count + 1;
            
            if formant_count > 3
                break;
            end
            
        end
        
    end
            
end


% for i=2:fs/2
%     
%     if mag_spec_s(i-1) > 0
%         
%         if mag_spec_s(i) < 0
%             
%             formant(formant_count) = i;
%             
%             formant_count = formant_count + 1;
%             
%             if formant_count > 3
%                 break;
%             end
%             
%         end
%         
%     end
%             
% end

formant1 = formant(1);

formant2 = formant(2);

formant3 = formant(3);

%% 3 DB BANDWIDTH ENERGY IN FORMANTS

formant1_energy = 0;
formant2_energy = 0;
formant3_energy =  0;

% % FOR FORMANT 1
% 
% peak_mag = HDNGD(formant1); 
% 
% for i=1:(fs/2 - formant1)
%     
%     if i == (fs/2 - formant1)
%         
%         end_band = formant1 + i - 1;
%         
%         break;
%         
%     end
%     
%     if HDNGD(formant1 + i - 1) < (0.707 * peak_mag)
%         
%         end_band = formant1 + i - 1;
%         
%         break;
%         
%     end
%     
% end
% 
% for i=1:(formant1)
%     
%     if i == (formant1)
%         
%         start_band = formant1 - i + 1;
%         
%         break;
%         
%     end
%     
%     if HDNGD(formant1 - i + 1) < (0.707 * peak_mag)
%         
%         start_band = formant1 - i + 1;
%         
%         break;
%         
%     end
%     
% end
% 
% formant1_energy = sum(HDNGD(start_band:end_band).*HDNGD(start_band:end_band));
% 
% 
% % FOR FORMANT 2
% 
% peak_mag = HDNGD(formant2); 
% 
% for i=1:(fs/2 - formant2)
%     
%     if i == (fs/2 - formant2)
%         
%         end_band = formant2 + i - 1;
%         
%         break;
%         
%     end
%     
%     if HDNGD(formant2 + i - 1) < (0.707 * peak_mag)
%         
%         end_band = formant2 + i - 1;
%         
%         break;
%         
%     end
%     
% end
% 
% for i=1:(formant2)
%     
%     if i == (formant2)
%         
%         start_band = formant2 - i + 1;
%         
%         break;
%         
%     end
%     
%     if HDNGD(formant2 - i + 1) < (0.707 * peak_mag)
%         
%         start_band = formant2 - i + 1;
%         
%         break;
%         
%     end
%     
% end
% 
% formant2_energy = sum(HDNGD(start_band:end_band).*HDNGD(start_band:end_band));
% 
% 
% % FOR FORMANT 3
% 
% peak_mag = HDNGD(formant3); 
% 
% for i=1:(fs/2 - formant3)
%     
%     if i == (fs/2 - formant3)
%         
%         end_band = formant3 + i - 1;
%         
%         break;
%         
%     end
%     
%     if HDNGD(formant3 + i - 1) < (0.707 * peak_mag)
%         
%         end_band = formant3 + i - 1;
%         
%         break;
%         
%     end
%     
% end
% 
% for i=1:(formant3)
%     
%     if i == (formant3)
%         
%         start_band = formant3 - i + 1;
%         
%         break;
%         
%     end
%     
%     if HDNGD(formant3 - i + 1) < (0.707 * peak_mag)
%         
%         start_band = formant3 - i + 1;
%         
%         break;
%         
%     end
%     
% end
% 
% formant3_energy = sum(HDNGD(start_band:end_band).*HDNGD(start_band:end_band));


band_energy = formant1_energy + formant2_energy + formant3_energy;
