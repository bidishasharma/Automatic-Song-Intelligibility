function [X, f_r, t_r] = svlSpgram(x, n, Fs, window, overlap, clipdB, maxfreq)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Usage: 
% [X [, f [, t]]] = svlSpgram(x [, n [, Fs [, window [, overlap[, clipdB [, maxfreq ]]]]]])
%
% 	Generate a spectrogram for the signal. This chops the signal into
% 	overlapping slices, windows each slice and applies a Fourier
% 	transform to determine the frequency components at that slice.
%
% INPUT:
% 	x: signal or vector of samples
% 	n: size of fourier transform window, or [] for default=256
% 	Fs: sample rate, or [] for default=2 Hz
% 	window: shape of the fourier transform window, 
%		or [] for default=hanning(n)
%		Note: window length can be specified instead, in which case
%    		window=hanning(length)
% 	overlap: overlap with previous window, 
%		or [] for default=length(window)/2
%	clipdB:	Clip or cut-off any spectral component more than 'clipdB' 
%		below the peak spectral strength.(default = 35 dB)
%	maxfreq: Maximum freq to be plotted in the spectrogram (default = Fs/2)
%
% OUTPUT:
%	X: STFT of the signal x
%	f: The frequency values corresponding to the STFT values
%	t: Time instants at which the STFT values are computed
% 
% Example
%--------
%	x = chirp([0:0.001:2],0,2,500);  # freq. sweep from 0-500 over 2 sec.
%	Fs=1000;                  # sampled every 0.001 sec so rate is 1 kHz
%	step=ceil(20*Fs/1000);    # one spectral slice every 20 ms
%	window=ceil(100*Fs/1000); # 100 ms data window
%	svlSpgram(x, 2^nextpow2(window), Fs, window, window-step);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Original version by Paul Kienzle; modified by Sean Fulop March 2002
%
% Customized by Anand and then by Dhananjaya
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  if nargin < 1 | nargin > 7
    error('usage: ([Y [, f [, t]]] = svlSpgram(x [, n [, Fs [, window [, overlap[, clipdB]]]]]) ')
  end

  % assign defaults
  if nargin < 2 | isempty(n), n = min(256, length(x)); end
  if nargin < 3 | isempty(Fs), Fs = 2; end
  if nargin < 4 | isempty(window), window = hanning(n); end
  if nargin < 5 | isempty(overlap), overlap = length(window)/2; end
  if nargin < 6 | isempty(clipdB), clipdB = 35; end % clip anything below 35 dB
  if nargin < 7 | isempty(maxfreq), maxfreq = Fs/2; end 

  % if only the window length is given, generate hanning window
  if length(window) == 1, window = hanning(window); end

  % should be extended to accept a vector of frequencies at which to
  % evaluate the fourier transform (via filterbank or chirp
  % z-transform)
  if length(n)>1, 
    error('spgram doesn''t handle frequency vectors yet') 
  end

  % compute window offsets
  win_size = length(window);
  if (win_size > n)
    n = win_size;
    warning('spgram fft size adjusted---must be at least as long as frame')
  end
  step = win_size - overlap;

  % build matrix of windowed data slices
  S = buffer(x,win_size,overlap,'nodelay');
  W = window(:,ones(1,size(S,2)));
  S = S .* W;
  offset = [0:size(S,2)-1]*step;

  % compute fourier transform
  STFT = fft(S,n);
     
  % extract the positive frequency components
  if rem(n,2)==1
    ret_n = (n+1)/2;
  else
    ret_n = n/2;
  end

  STFT = STFT(1:ret_n, :);

  f = [0:ret_n-1]*Fs/n;
  t = offset/Fs;
  
  if nargout>1, f_r = f; end
  if nargout>2, t_r = t; end

  %maxfreq = Fs/2;
  STFTmag = abs(STFT(1:round(n*maxfreq/Fs),:)); % magnitude of STFT
  STFTmag = STFTmag/max(max(STFTmag)); % normalize so max magnitude will be 0 db
  STFTmag = max(STFTmag, 10^(-clipdB/10)); % clip everything below -35 dB

  if nargout>0, X = STFTmag; end
 
% display as an indexed grayscale image showing the log magnitude of the STFT, 
% i.e. a spectrogram; the colormap is flipped to invert the default setting,
% in which white is most intense and black least---in speech science we want
% the opposite of that.
% imagesc(t, f(2:n*maxfreq/Fs), 20*log10(STFTmag)); axis xy; colormap(flipud(gray));

twby2=round(win_size/2)/Fs;

  if nargout==0
  if Fs<2000
	%imagesc(t+twby2, f(2:round(n*maxfreq/Fs)), 20*log10(STFTmag));
	pcolor(t+twby2, f(1:n*maxfreq/Fs), 20*log10(STFTmag));
	ylabel('Hz');
  else
        %imagesc(t, f(2:n*maxfreq/Fs)/1000, 20*log10(STFTmag));
        pcolor(t+twby2, f(1:round(n*maxfreq/Fs))/1000, 20*log10(STFTmag));
        ylabel('kHz');
  end
  axis xy;
  colormap(flipud(gray));
  shading interp;
  %xlabel('Time (seconds)');
  end 

