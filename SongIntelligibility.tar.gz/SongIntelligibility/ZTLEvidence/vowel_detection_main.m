clc; clear all;

%% INPUTs

% WAVE FILE

%[s10 fs]=wavread('/media/A0084CC9084CA060/biswa_pc_backup/harddisk1/tata_project/data/2_spkrstata_test/bonti_data/ASF012AS_a/wav/ASF012AS_a01.wav');
%[s fs]=wavread('/media/A0084CC9084CA060/biswa_pc_backup/harddisk1/tata_project/data/2_spkrstata_test/bonti_data/ASF012AS_a/wav/ASF012AS_a01.wav');
[s10 fs]=wavread('/home/queen/PHD/syll_rate/test_wav/ASF001-AS-ST02U15.wav');
%[s10 fs]=wavread('./TEST_DR2_FSLB1_SA1.wav');
%[s fs]=wavread('./TEST_DR2_MCCS0_SX299.wav');

%% ADD NOISE

rnl = 50;

[s,final_noise_seq]=add_white_noise(s10,rnl);

%%
%s = s(1:5650);

s = s / max(abs(s));

% FRAMESIZE

Framesize = 3; % MILLISECOND

%% GET THE EPOCHS

%[zffo1,gclocssp1,epssp1,f0sp1]=svlzfsig2(s, fs, 8);
[gclocssp1,vgclocssp1,epstrsp1,winlength,zsp1,vf0sp1,vepochstr]=EpochsbyZFF(s,fs);

%% GET THE EPOCH INSTANTS

for i=1:length(s)
    for j=1:length(gclocssp1)
      if (i==gclocssp1(j))
          gclins_plot1(i)=1;
          break;
      else
          gclins_plot1(i)=0;
      end
    end
end



%% GET SPECTRAL ENERGY FROM ZERO TIME WINDOWED SIGNAL AT THE EPOCH LOCATIONS 

present_formant1 = 0; 
present_formant2 = 0;
present_formant3 = 0;



for i=1:length(s)
    
    %if i > length(s)-(Framesize*.001*fs-1+100)
    if gclins_plot1(i) == 0
        spectral_energy(i) = 0;
        spectral_energy1(i) = 0;
        formant1(i) = present_formant1;
        formant2(i) = present_formant2;
        formant3(i) = present_formant3;
        band_energy(i) = 0;
    else
        [spectral_energy(i) spectral_energy1(i) formant1(i) formant2(i) formant3(i) band_energy(i)]= main_prog(s(i:(i+Framesize*.001*fs-1)), Framesize, fs);
        present_formant1 = formant1(i);
        present_formant2 = formant2(i);
        present_formant3 = formant3(i);
    end
end

spectral_energy = spectral_energy / max(abs(spectral_energy));

spectral_energy1 = spectral_energy1 / max(abs(spectral_energy1));

band_energy = band_energy / max(abs(band_energy));

% formant1 = formant1 / max(abs(formant1));
% 
% formant2 = formant2 / max(abs(formant2));
% 
% formant3 = formant3 / max(abs(formant3));


%% PLOTS
subplot(211);
plot(s);
subplot(212);
plot(gclins_plot1);

ax(1)=subplot(211);
ax(2)=subplot(212);
linkaxes(ax,'x');

% %% temp for fricatives
% for i=1:length(spectral_energy)
%     if spectral_energy(i) < 1500
%         i=i;
%     else
%     spectral_energy(i) = 0;
%     end
% end
% 
% spectral_energy = spectral_energy / max(abs(spectral_energy));

%% SPECTRAL ENERGY PLOTS

figure;
plot(s10);
hold on;
plot(spectral_energy, 'r');

figure;
plot(s10);
hold on;
plot(spectral_energy1, 'r');



figure;q(1)=subplot(3,1,1);plot(s10)
q(2)=subplot(3,1,2);plot(spectral_energy);
q(3)=subplot(3,1,3);plot(spectral_energy1);
linkaxes(q,'x');


% figure;
% plot(s10);
% hold on;
% plot(band_energy, 'r');

% figure;
% subplot(211);
% plot(s10);
% 
% subplot(212);
% plot(formant1, 'r');
% 
% hold on;
% plot(formant2, 'k');
% 
% 
% hold on;
% plot(formant3, 'm');
% 
% ax(1)=subplot(211);
% ax(2)=subplot(212);
% linkaxes(ax,'x');

%% mean smoothing
smooth_window_size = (50*fs)/1000;

smoothed_spectral_energy=meansmooth(spectral_energy,smooth_window_size,0); 

plot(s10); hold on; plot(smoothed_spectral_energy, 'r');

%FIND THE SLOPE
MD1=diff(smoothed_spectral_energy);MD1=MD1./max(abs(MD1));

%MEDIAN FILTERING TO REMOVE THE SPIKES
D1=medfilt1(MD1,5);

figure;
plot(s10); hold on; plot(MD1, 'r');


%FIND THE POS ZC  (PEAKS)
plotflag=0;
[PN1,SLP1]=findpostonegzc_V3(D1,2,40);
In1=find(PN1==1);
[Ind11,Ind13,Ind12,Me1]=Tempfun_V6(smoothed_spectral_energy,SLP1,In1,1,0.5*mean(smoothed_spectral_energy),400,plotflag);


%FIND THE NEG ZC (VALLEY)
NP1=findnegtoposzc(D1,5);Ind1=find(NP1==1);