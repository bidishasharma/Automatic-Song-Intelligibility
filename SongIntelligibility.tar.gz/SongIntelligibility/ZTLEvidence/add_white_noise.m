function [noise_added_sig,final_noise_seq]=add_white_noise(inputsig,rnl)

%[noiseaddedsignal,finalnoiseseq]=add_white_noise(inputsig,desiredlenvel(in
%dB))



%[white_noise]=wavread('white.wav');

white_noise = randn(1,length(inputsig))';


gen_noise_seq= white_noise(1:length(inputsig));
%gen_noise_seq=randn(length(inputsig),1);


gen_noise_enrg=sum((gen_noise_seq).^2)/length(gen_noise_seq);
inputsig_enrg=sum((inputsig).^2)/length(inputsig);

reqrd_noise_power=inputsig_enrg/(10^(rnl/10));

mltpc_factor=sqrt(reqrd_noise_power/gen_noise_enrg);

final_noise_seq=gen_noise_seq*mltpc_factor;

noise_added_sig=inputsig+final_noise_seq;

final_noise_enrg=sum((final_noise_seq).^2)/length(final_noise_seq);
Added_SNR=10*log10(inputsig_enrg/final_noise_enrg);
Noise_level=10*log10(final_noise_enrg);

noise_added_sig=noise_added_sig/(1.01*max(abs(noise_added_sig)));