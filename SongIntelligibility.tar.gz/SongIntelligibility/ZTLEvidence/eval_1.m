%% PTAH
refine = 0;
% Reference File
mlf_file_path = '/media/8CE857EEE857D4D4/biswa/INDICON2013/Syllabification/programms/files/reference/132373_4.lab';

% Output File
out_put_file_path = '/media/8CE857EEE857D4D4/biswa/INDICON2013/Syllabification/programms/files/output_hmm/132373_4.mlf';

% Write output to a file
output_text = '/media/8CE857EEE857D4D4/biswa/INDICON2013/Syllabification/programms/text.txt';

%% READ REFERENCE FILE
fs = 8000;

fid = fopen(mlf_file_path);
A = fscanf(fid, '%c', [1 inf]);
A1=A;
fclose(fid);
line_count=0;col_count=0;

col_char='';j=1;col1=[];col2=[];col3=[];

for i=1:length(A)
  if A(i)==A(22)
      line_count=line_count + 1
      col_count=0;
      col_char='';
  end
  if line_count > 1
      if A(i)==A(10)
          col_char;
          col_count=col_count+1;
          %B(line_count-2, j)=col_char;
          j=j+1;
          if col_count == 1
          col_char1=str2num(col_char);
          col1=[col1 col_char1];
          end
          if col_count == 2
          col_char1=str2num(col_char);
          col2=[col2 col_char1];
          end
          if col_count == 3
             col_char1=str2num(col_char);
          col3=[col3 col_char1];
          end
          col_char='';
      else
          col_char=strcat(col_char, A(i));
      end
 
      
  end
end
col1=col1*fs;
%col2=col2*.0000001*fs;

ref_col = col1;

%% OUTPUT FILE


fid = fopen(out_put_file_path);
A = fscanf(fid, '%c', [1 inf]);
fclose(fid);
line_count=0;col_count=0;

col_char='';j=1;col1=[];col2=[];col3=[];ave_dev=[];

for i=1:length(A)
  if A(i)==A1(22)
      line_count=line_count + 1
      col_count=0;
      col_char='';
  end
  if line_count > 1
      if A(i)==A1(10)
          col_char;
          col_count=col_count+1;
          %B(line_count-2, j)=col_char;
          j=j+1;
          if col_count == 1
          col_char1=str2num(col_char);
          col1=[col1 col_char1];
          end
          if col_count == 2
          col_char1=str2num(col_char);
          col2=[col2 col_char1];
          end
          if col_count == 3
             col_char1=str2num(col_char);
          col3=[col3 col_char1];
          end
          col_char='';
      else
          col_char=strcat(col_char, A(i));
      end
 
      
  end
end
col1=col1*fs;
%col2=col2*.0000001*fs;
output_col = col1;

%% refine output

if refine == 0
else
[n] = voptest();



[xx vop_col] = findpeaks(n); 

for i=1:length(output_col)
    
    for j=1:length(vop_col)
        
       if abs(output_col(i)-vop_col(j)) < (20 * .001 * fs) 
           
           output_col(i) = vop_col(j);
           
       end
        
    end
    
end
end
%% Cost
detected = 0;spu_detected = 0;spu_x=[];

for i=1:length(output_col)
    
    for j=1:length(ref_col)
        
        if abs(output_col(i) - ref_col(j)) < (40 * .001 * fs)
            
            detected = detected + 1;
            
            ave_dev(i) = abs(output_col(i) - ref_col(j));
            
            break;
                                 
        elseif j == length(ref_col)
            spu_detected = spu_detected + 1;
            spu_x = [spu_x i];
        end
    
    end
end
    
%% WRITE OUTPUT TO A TEXT FILE

stnd_dev = sqrt(sum(ave_dev.*ave_dev)/length(ave_dev));

ave_dev1 = sum(ave_dev)/(.001 * fs * detected);

detected;

spu_detected;


fid = fopen(output_text, 'a');
fprintf(fid, '%d', detected);
fprintf(fid, '%c', ' ');
fprintf(fid, '%d', spu_detected);
fprintf(fid, '%c', ' ');
fprintf(fid, '%d', stnd_dev);
fprintf(fid, '%c', ' ');
fprintf(fid, '%d', ave_dev1);
fprintf(fid, '%c\n', ' ');

fclose(fid);


 %[s n] = voptest()
%  s=s/max(abs(s));
%  plot(s);
%  hold on;
%  plot(n, 'r');
% grid on;

%s, n ref_col output_col vop_col

% ref_col_plot = zeros(1, length(s));
% 
% output_col_plot = zeros(1, length(s));
% 
% vop_col_plot = zeros(1, length(s));
% 
% for i=1:length(s)
%     
%     for j=1:length(ref_col)
%        if i == ref_col(j)
%            ref_col_plot(i) = .8;
%        end
%     end
%     
%     for j=1:length(output_col)
%        if i == output_col(j)
%            output_col_plot(i) = .8;
%        end
%     end
%     
%     for j=1:length(vop_col)
%        if i == vop_col(j)
%            vop_col_plot(i) = .8;
%        end
%     end
%     
%        
% end
% 
% plot(s);
% hold on;
% plot(ref_col_plot,'r');
% 
% figure;
% 
% plot(s);
% hold on;
% plot(output_col_plot,'r');
% 
% figure;
% 
% plot(s);
% hold on;
% plot(vop_col_plot,'r');
