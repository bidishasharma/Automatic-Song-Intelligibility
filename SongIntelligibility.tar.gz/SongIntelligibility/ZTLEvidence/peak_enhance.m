
function [MSMSR]= peak_enhance(x,Fs);

MD2=diff(x);MD2=MD2./max(abs(MD2));
D2=medfilt1(MD2,5);

[PN2,SLP2]=findpostonegzc_V3(D2,2,40);
In2=find(PN2==1);
[Ind21,Ind23,Ind22,Me2]=Tempfun_V6(x,SLP2,In2,1,0.1*mean(x),400,0);

NP2=findnegtoposzc(D2,5);Ind2=find(NP2==1);
[MSMSR,Index2r]=regions_V2(x,Ind22,Ind2,0); %% give the energy value here