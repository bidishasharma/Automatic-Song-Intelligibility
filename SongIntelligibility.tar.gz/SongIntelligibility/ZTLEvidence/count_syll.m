function [ syll_no] = count_syll(syll_n);

L_part=round(length(syll_n)/3);
end_ind=0;

for i=0:2
    
    if (i==2)
        
    tmp=syll_n(end_ind+1:end);
    
    else
        
    strt=end_ind+1;
    end_ind=i*L_part+L_part+1;
    tmp=syll_n(strt:end_ind);
    
    end;
    
    syll_no(i+1)=nnz(tmp);
    clear tmp;
    
    
end;