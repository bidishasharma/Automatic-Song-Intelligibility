function [hngdatepoch,ngdloc,f,hngd,xgci] = ztl3d(s,nbeg,ndur,fs,nfft,nwin,PLOTFLAG)

%%%%%%%%%%%%%%%%%%%
% Usage: [hngdatepoch,t,f,hngd] = ztl3d(s,nbeg,ndur,fs,nfft,nwin,PLOTFLAG)
%
% nbeg=2500;ndur=500;fs=10000;nfft=2^11;n1ms=round(fs/1000);nwin=5*n1ms;
%
% s=resample(s,10000,fs);
% fs=10000;
% s=preemphasize(s,0.5);
%%%%%%%%%%%%%%%%%%%%%%%

[zf,gci,es,f0,extra]=zfsig(s,fs);

x=s(nbeg+[0:ndur-1]);

clear hngd;
for i=1:length(x)-nwin
    y=x(i:i+nwin-1);
    [hngd(:,i),f]=ztl(y,fs,nfft,nwin,0);
end

hngdmax=max(hngd);

xgci=gci(find(gci>nbeg & gci<nbeg+ndur+1));
xgci=xgci-nbeg+1;
if(xgci(end)>size(hngd,2))
    xgci(end)=[];
end

n1ms=round(fs/1000);
%clear ngdloc ngdpeakval;
for k=1:length(xgci)
    if(k==1)
        fbeg=max(1,xgci(k)-5*n1ms);
    else
        fbeg=ceil((xgci(k)+xgci(k-1))/2);
    end
    if(k==length(xgci))
        fend=min(size(hngd,2),xgci(k)+5*n1ms);
    else
        fend=floor((xgci(k)+xgci(k+1))/2);
    end
    [emax,eloc]=max(hngdmax(fbeg:fend));
    
    ngdloc(k)=fbeg+eloc-1;
    ngdpeakval(k)=emax;
end
% clear ngdloc ngdpeakval;
% for k=1:length(xgci)
%     fbeg=xgci(k);
%     if(k==length(xgci))
%         fend=min(size(ngd,2),xgci(k)+5*n1ms);
%     else
%         fend=xgci(k+1);
%     end
%     [emax,eloc]=max(ngdmax(fbeg:fend));
%     %[emax,eloc]=max(ngdenr(fbeg:fend));
%     ngdloc(k)=fbeg+eloc-1;
%     ngdpeakval(k)=emax;
% end

hngdatepoch=hngd(:,ngdloc);

h=1-exp(-.1*hngd); 
h1=1-exp(-.1*hngdatepoch);

if(exist('PLOTFLAG') & PLOTFLAG==1)
    %%%%%%%%%%%%%%%%%%%%%%%
    figure;waterfall(f,ngdloc/fs*1000,hngdatepoch');colormap([0 0 0]);axis ij;
    xlabel('Hz');ylabel('Time (ms)');
    set(gca,'view',[30 65]);
    fig=gcf;
    allText   = findall(fig, 'type', 'text');
    allAxes   = findall(fig, 'type', 'axes');
    allFont   = [allText; allAxes];
    set(allFont,'FontSize',12,'fontweight','bold');

    alllines=findall(fig,'type','line');
    set(alllines,'linewidth',1.5);

    %%%%%%%%%%%%%%%%%%%%%%%
    ndx=[1:size(hngd,2)];
    t=(ndx-1)/fs;
    fig=figure;clear ax;nr=4;nc=1;i=1;
    applytofig(fig,'width',30,'height',20,'color','cmyk');
    ax(i)=subplot(nr,nc,i);plot(t,x(ndx)/max(abs(x(ndx))));i=i+1;
        %text(1.1,0.7,'(a) Speech waveform');ylim([-1.5 1]);
    ax(i)=subplot(nr,nc,i);pcolor(ngdloc/fs,f/1000,(h1).^.5);i=i+1;
    %ax(i)=subplot(nr,nc,i);pcolor(t,f/1000,(h).^.5);i=i+1;
        colormap(flipud(gray));shading interp;axis xy;ylabel('kHz'); 
        %text(1.1,4.5,'(b) HNGD spectrogram');   
    ax(i)=subplot(nr,nc,i);svlSpgram(x,2^11,fs,5*n1ms,4*n1ms,30);i=i+1;
        %text(1.1,4.5,'(c) WB spectrogram');
    ax(i)=subplot(nr,nc,i);svlSpgram(x,2^11,fs,30*n1ms,29*n1ms,30);i=i+1;
        xlabel('Time (s)');
        %text(1.1,4.5,'(d) NB spectrogram');
    linkaxes(ax,'x');
    xlim([t(1) t(end)]);

    for i=1:nr-1;set(ax(i),'xtick',[]);end;

    xbeg=0.1;xwidth=0.8;ybeg=0.1;ybuff=0.1/(nr-1);
    yheight=[0.1 .2 .2 .2];
    for i=nr:-1:1
        set(ax(i),'position',[xbeg,ybeg,xwidth,yheight(i)]);
        ybeg=ybeg+yheight(i)+ybuff;
    end

    fig=gcf;
    allText   = findall(fig, 'type', 'text');
    allAxes   = findall(fig, 'type', 'axes');
    allFont   = [allText; allAxes];
    set(allFont,'FontSize',12,'fontweight','bold');

    alllines=findall(fig,'type','line');
    set(alllines,'linewidth',1.5);
    %%%%%%%%%%%%%%%%%%%%%%%
end

return;