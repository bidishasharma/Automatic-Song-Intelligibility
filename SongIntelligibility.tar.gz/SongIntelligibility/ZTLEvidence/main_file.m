clear all;
[sample,fs]=wavread('SA1.wav');
[xind,sp1sig,zsp1,epstrsp1,vgclocssp1,vf0sp1,fs]=zff_computefn(sample,fs);
figure();
subplot(4,1,1);plot(xind,sp1sig./(1.05*max(sp1sig)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,2);plot(xind,zsp1./(1.05*max(zsp1)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,3);plot(xind,epstrsp1/(1.05*max(epstrsp1)));axis([min(xind),max(xind),0,1.1]);grid;
subplot(4,1,4);plot(vgclocssp1/(fs),(vf0sp1),'.','markersize',15);axis([min(xind),max(xind),10,400]);grid;
title('CLEAN SPEECH SIGNAL')
ax(1)=subplot(4,1,1);
  ax(2)=subplot(4,1,2);
   ax(3)=subplot(4,1,3);
    ax(4)=subplot(4,1,4);
      linkaxes(ax,'x');
      
      
    clear all;
[sample,fs]=wavread('music_speech_transition.wav');
[xind,sp1sig,zsp1,epstrsp1,vgclocssp1,vf0sp1,fs]=zff_computefn(sample,fs);
figure();
subplot(4,1,1);plot(xind,sp1sig./(1.05*max(sp1sig)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,2);plot(xind,zsp1./(1.05*max(zsp1)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,3);plot(xind,epstrsp1/(1.05*max(epstrsp1)));axis([min(xind),max(xind),0,1.1]);grid;
subplot(4,1,4);plot(vgclocssp1/(fs),(vf0sp1),'.','markersize',15);axis([min(xind),max(xind),10,400]);grid;
 title('MUSIC_SPEECH_TRANSITION')
ax(1)=subplot(4,1,1);
  ax(2)=subplot(4,1,2);
   ax(3)=subplot(4,1,3);
    ax(4)=subplot(4,1,4);
      linkaxes(ax,'x');
      
      clear all;
[sample,fs]=wavread('speech_music_background.wav');
[xind,sp1sig,zsp1,epstrsp1,vgclocssp1,vf0sp1,fs]=zff_computefn(sample,fs);
figure();
subplot(4,1,1);plot(xind,sp1sig./(1.05*max(sp1sig)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,2);plot(xind,zsp1./(1.05*max(zsp1)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,3);plot(xind,epstrsp1/(1.05*max(epstrsp1)));axis([min(xind),max(xind),0,1.1]);grid;
subplot(4,1,4);plot(vgclocssp1/(fs),(vf0sp1),'.','markersize',15);axis([min(xind),max(xind),10,400]);grid;
 title('MUSIC_SPEECH_BACKGROUND1')
ax(1)=subplot(4,1,1);
  ax(2)=subplot(4,1,2);
   ax(3)=subplot(4,1,3);
    ax(4)=subplot(4,1,4);
      linkaxes(ax,'x');
      
      clear all;
[sample,fs]=wavread('speech_music_background_2.wav');
[xind,sp1sig,zsp1,epstrsp1,vgclocssp1,vf0sp1,fs]=zff_computefn(sample,fs);
figure();
subplot(4,1,1);plot(xind,sp1sig./(1.05*max(sp1sig)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,2);plot(xind,zsp1./(1.05*max(zsp1)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,3);plot(xind,epstrsp1/(1.05*max(epstrsp1)));axis([min(xind),max(xind),0,1.1]);grid;
subplot(4,1,4);plot(vgclocssp1/(fs),(vf0sp1),'.','markersize',15);axis([min(xind),max(xind),10,400]);grid;
 title('MUSIC_SPEECH_BACKGROUND2')
ax(1)=subplot(4,1,1);
  ax(2)=subplot(4,1,2);
   ax(3)=subplot(4,1,3);
    ax(4)=subplot(4,1,4);
      linkaxes(ax,'x');
      
      clear all;
      [sample,fs]=wavread('s_m_b.wav');
[xind,sp1sig,zsp1,epstrsp1,vgclocssp1,vf0sp1,fs]=zff_computefn(sample,fs);
figure();
subplot(4,1,1);plot(xind,sp1sig./(1.05*max(sp1sig)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,2);plot(xind,zsp1./(1.05*max(zsp1)));axis([min(xind),max(xind),-1.1,1.1]);grid;
subplot(4,1,3);plot(xind,epstrsp1/(1.05*max(epstrsp1)));axis([min(xind),max(xind),0,1.1]);grid;
subplot(4,1,4);plot(vgclocssp1/(fs),(vf0sp1),'.','markersize',15);axis([min(xind),max(xind),10,400]);grid;
 title('MUSIC_SPEECH_BACKGROUND3')
ax(1)=subplot(4,1,1);
  ax(2)=subplot(4,1,2);
   ax(3)=subplot(4,1,3);
    ax(4)=subplot(4,1,4);
      linkaxes(ax,'x');