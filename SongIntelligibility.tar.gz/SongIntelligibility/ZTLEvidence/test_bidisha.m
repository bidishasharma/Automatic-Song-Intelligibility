clc;
clear all;
close all;

[file,fs]=wavread('/home/queen/PHD/syll_rate/test_wav/ASF001-AS-ST02U15.wav');
x=file(:,1);
x=x(round(1.81*fs):round(1.87*fs));
%[En_threshld] = energy(x,fs);

factor=fs/(2*1200);
points=round(1024/factor);
%x=x(1.9*fs:3.3*fs); %vowel 
[zffo,epochlocs1,epssp1,f0sp1]=svlzfsig2(x,fs,7);
epochlocs=zeros(1,length(epochlocs1));
epochlocs(1)=epochlocs1(1);
epochlocs(end)=epochlocs1(end);

res1= LPres(x,fs,20,10,10,1);
%%------------------------------------------HE of LP residual
hensp1=HilbertEnv(res1,fs,0);
he2=abs(hensp1);
he1=he2./max(abs(he2));


for k=2:length(epochlocs1)-1
    
    strt=round(epochlocs1(k)-2.864*10^-3*fs);
    stpt=round(epochlocs1(k)+2.894*10^-3*fs);
    
    
    if (strt<1)
      strt=1;
        
    end;
    
    if(stpt>length(x)) 
        stpt=length(x);
    end;
    
    [m ind]=max(he1(strt:stpt));
    
    epochlocs(k)=strt+ind-1;
    
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

epochs=zeros(1,length(epochlocs));
eplochs(epochlocs)=1;
PLOTFLAG = 0;
nfft = 2^11;
All_hngd=[];
All_mean=[];
All_1st_dim=[];
All_pk_2val=[];

All_mean=[];


for i=2:length(epochlocs)-1
    
    
    
    strt=epochlocs(i)-2.5*10^-3*fs;
    stpt=epochlocs(i)+2.5*10^-3*fs;
    if (strt<0)
        strt=1;
    end;
    
    if (stpt>epochlocs(end))
        stpt=epochlocs(end);
    end;
    
    nwin=stpt-strt;
    
  [hngd,f,dngd,ngd,mag,hgd,dgd,gd,w] =ztl(x(strt:stpt),fs,nfft,nwin,0);
  %hngd=hngd./max(hngd);
  
  mag_spec_s=abs(fft(x, 1025));
  
  figure; p(1)=subplot(3,1,1);plot(x);
  p(2)=subplot(3,1,2);plot(hngd);
  p(3)=subplot(3,1,3);plot(mag_spec_s(1:300));
  

  

end;