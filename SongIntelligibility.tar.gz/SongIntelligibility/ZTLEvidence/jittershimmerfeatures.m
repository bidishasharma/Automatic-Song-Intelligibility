% This programm is written to find jitter features from the speech signal

function [jitterabs,shimmerabs,vepochstr,vgclocssp1]=jittershimmerfeatures(sp1sig,fs,noofpitchperiod,fsizems,fshiftms)

% sp1sig=input speech signal
% noofpitchperiod=number of extracted pitch period taken for computation of
% jitter and shimmer.
% overlap=overlapping in pitch segments;
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%program for instantaneous F0 in multispeaker environment
%this program generates various figures used in the paper.

%load two mic signals
% close all
% clear all
% clc

%computing pitch contours from given speakers data
% sp1sig=sphere2mulaw('D:\programms\NIST_1999\30\Test/ebwa.sph');
% sp1sig=sphere2mulaw('D:\programms\NIST_1999\30\Train/4001A.sph');

% sp1sig = wavReadTimitv2('D:\programms\TIMIT\TIMIT\TEST\DR1\FAKS0/sa1.wav');

%resample for timit
% sp1sig = resample(sp1sig,1,2);

%uncomment for NIST
%sp1sig=sp1sig(1:40000);

if(size(sp1sig,2) ~= 1)
    sp1sig=sp1sig';
end

sp1sig=sp1sig./(1.01*max(abs(sp1sig)));

%fs=8000; %original timit at 16k

% sound(sp1sig,fs);

%compute lp residual

ressp1=LPres(sp1sig,fs,fsizems,fshiftms,10,1);

clear sp1sig

%compute Hilbert envelope

hensp1=HilbertEnv(ressp1,fs,1);

clear ressp1

avgpitchperiod=HilbertAvgPitch(hensp1,fs,(fsizems*fs)/1000,(fshiftms*fs)/1000)

% mysmwin=ones(8,1);
% 
% shensp1=conv(hensp1,mysmwin);
% 
% hensp1=shensp1(floor(length(mysmwin)/2):length(shensp1)-floor(length(mysmwin)/2));
% 
% henvsp1=RemTrend(hensp1,fs,4);
% henvsp1=RemTrend(hensp1,fs,4);

%  figure;
%  subplot(3,1,1);plot(sp1sig);grid;
%  subplot(3,1,2);plot(ressp1);grid;
%  subplot(3,1,3);plot(hensp1);grid;
%  pause


%hensp1=hensp1.*hensp1;

winlength=round(avgpitchperiod);
[zsp1,gclocssp1,epssp1,f0sp1]=svlzfsig2(hensp1,fs,winlength);

clear zsp1;
%clear gclocssp1;

epssp1=epssp1./(max(epssp1));

epochstr=epssp1;

meanessp1=mean(epssp1);

% epstrsp1=zeros(length(hensp1),1);
% epstrsp1(gclocssp1)=epssp1;

%voicing decision
epssp1=epssp1>0.5*meanessp1;

%%Added by Bidisha on 21st june 2018
indx1=find(epssp1>0.5*meanessp1);
vgclocssp1=gclocssp1(indx1);
%vgclocssp1=gclocssp1(epssp1);
vf0sp1=f0sp1(epssp1);

meanF0=mean(vf0sp1);
sdevF0=std(vf0sp1);


%use this for computing Jitter
vf0sp1=medfilt1(vf0sp1,5);
%pause

vt0sp1=1./vf0sp1;
%pause

dvt0sp1=abs(diff(vt0sp1));
%pause

 N=noofpitchperiod-1;
%  N=2;
% 
 wind=ones(N,1);

 jitterabs=conv(dvt0sp1,wind);


%  jitterabs=jitterabs./N;

%  jitterabs=jitterabs(floor(N/2):length(jitterabs)-floor(N/2));
jitterabs=jitterabs(N:length(jitterabs)-(N-1));

jitterabs=jitterabs./N;

% [jitterabsfreq,jitterabsxaxis]=hist(jitterabs,5000);
% 
% jitterabsfreq=jitterabsfreq./sum(jitterabsfreq);
% 
% 
% figure;bar(jitterabsxaxis,jitterabsfreq);grid;

size(vt0sp1);

size(dvt0sp1);

size(jitterabs);




%use this for computing Shimmer
vepochstr=epochstr(epssp1);

dvepochstr=abs(20.*diff(log10(vepochstr)));

shimmerabs=conv(dvepochstr,wind);

shimmerabs=shimmerabs(N:length(shimmerabs)-(N-1));

shimmerabs=shimmerabs./N;

