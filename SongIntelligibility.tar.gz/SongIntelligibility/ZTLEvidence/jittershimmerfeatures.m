% This programm is written to find jitter features from the speech signal

function [jitterabs,shimmerabs]=jittershimmerfeatures(sp1sig,noofpitchperiod);

% sp1sig=input speech signal
% noofpitchperiod=number of extracted pitch period taken for computation of
% jitter and shimmer.
% overlap=overlapping in pitch segments;
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%program for instantaneous F0 in multispeaker environment
%this program generates various figures used in the paper.

%load two mic signals
% close all
% clear all
% clc

%computing pitch contours from given speakers data
% sp1sig=sphere2mulaw('D:\programms\NIST_1999\30\Test/ebwa.sph');
% sp1sig=sphere2mulaw('D:\programms\NIST_1999\30\Train/4001A.sph');

% sp1sig = wavReadTimitv2('D:\programms\TIMIT\TIMIT\TEST\DR1\FAKS0/sa1.wav');

%resample for timit
% sp1sig = resample(sp1sig,1,2);

%uncomment for NIST
%sp1sig=sp1sig(1:40000);

if(size(sp1sig,2) ~= 1)
    sp1sig=sp1sig';
end

sp1sig=sp1sig./(1.01*max(abs(sp1sig)));

fs=8000; %original timit at 16k

% sound(sp1sig,fs);

%compute lp residual

ressp1=LPres(sp1sig,fs,20,5,10,1);

clear sp1sig

%compute Hilbert envelope

hensp1=HilbertEnv(ressp1,fs,1);

clear ressp1

avgpitchperiod=HilbertAvgPitch(hensp1,fs,(30*fs)/1000,(10*fs)/1000);

% mysmwin=ones(8,1);
% 
% shensp1=conv(hensp1,mysmwin);
% 
% hensp1=shensp1(floor(length(mysmwin)/2):length(shensp1)-floor(length(mysmwin)/2));
% 
% henvsp1=RemTrend(hensp1,fs,4);
% henvsp1=RemTrend(hensp1,fs,4);

%  figure;
%  subplot(3,1,1);plot(sp1sig);grid;
%  subplot(3,1,2);plot(ressp1);grid;
%  subplot(3,1,3);plot(hensp1);grid;
%  pause


%hensp1=hensp1.*hensp1;

winlength=round(avgpitchperiod);
[zsp1,gclocssp1,epssp1,f0sp1]=svlzfsig2(hensp1,fs,winlength);

clear zsp1;
clear gclocssp1;

epssp1=epssp1./(max(epssp1));

epochstr=epssp1;

meanessp1=mean(epssp1);

% epstrsp1=zeros(length(hensp1),1);
% epstrsp1(gclocssp1)=epssp1;

%voicing decision
epssp1=epssp1>0.5*meanessp1;

%vgclocssp1=gclocssp1(epssp1);
vf0sp1=f0sp1(epssp1);

meanF0=mean(vf0sp1);
sdevF0=std(vf0sp1);


%use this for computing Jitter
vf0sp1=medfilt1(vf0sp1,5);
%pause

vt0sp1=1./vf0sp1;
%pause

dvt0sp1=abs(diff(vt0sp1));
%pause

 N=noofpitchperiod-1;
%  N=2;
% 
 wind=ones(N,1);

 jitterabs=conv(dvt0sp1,wind);


%  jitterabs=jitterabs./N;

%  jitterabs=jitterabs(floor(N/2):length(jitterabs)-floor(N/2));
jitterabs=jitterabs(N:length(jitterabs)-(N-1));

jitterabs=jitterabs./N;

% [jitterabsfreq,jitterabsxaxis]=hist(jitterabs,5000);
% 
% jitterabsfreq=jitterabsfreq./sum(jitterabsfreq);
% 
% 
% figure;bar(jitterabsxaxis,jitterabsfreq);grid;

size(vt0sp1);

size(dvt0sp1);

size(jitterabs);




%use this for computing Shimmer
vepochstr=epochstr(epssp1);

dvepochstr=abs(20.*diff(log10(vepochstr)));


shimmerabs=conv(dvepochstr,wind);


%  jitterabs=jitterabs./N;

%  jitterabs=jitterabs(floor(N/2):length(jitterabs)-floor(N/2));
shimmerabs=shimmerabs(N:length(shimmerabs)-(N-1));

shimmerabs=shimmerabs./N;



%comment below plot for jitter shimmer study
% xind=[1:length(sp1sig)]/8000;
% %  
% figure;
% subplot(4,1,1);plot(xind,hensp1./(1.05*max(hensp1)));axis([min(xind),max(xind),0,1.1]);grid;
% subplot(4,1,2);plot(xind,zsp1./(1.05*max(zsp1)));axis([min(xind),max(xind),-1.1,1.1]);grid;
% subplot(4,1,3);plot(xind,epstrsp1/(1.05*max(epstrsp1)));axis([min(xind),max(xind),0,1.1]);grid;
% subplot(4,1,4);plot(vgclocssp1/fs,vf0sp1,'.','markersize',15);axis([min(xind),max(xind),10,300]);grid;
% 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




% %datasamples=datasamples./max(abs(datasamples)); % data is normalised ;
% datasamples=datasamples-mean(datasamples); % mean average subtraction;
% 
% % computation of pith periods from the speech signal using
% % pitch_instant method(Yegnenarayana Sir);
% 
% [pitch_period1 pitch_freq1]=pitch_instant_version2(datasamples',Fs,1);
%  [M,VAD]=simplesumdftvad_V2(datasamples,Fs,(20*Fs)/1000,(10*Fs)/1000,0.95,0);
%  
%   pitch_period1=pitch_period1.*VAD;
% 
% % Spliting of the pitch periods into frames to obtain
% % the local variation in pitch from word to word
% % on an average 400ms are taken as the duration of a word
% % So frames are considered of 400ms duration with shift of 200ms
% 
% lframe=lframe*Fs/1000;
% overlap=overlap*Fs/1000;
% 
% incre=(overlap/lframe);
% lpitch_period1=length(pitch_period1);
% no_frame=floor(lpitch_period1/lframe);
% frame1=[];
% for m=1:incre:no_frame
%     frame=pitch_period1(floor(lframe*(m-1))+1:floor(lframe*m));
%     frame1=[frame1;frame];
% end
% pp=0;
% for ii=1:size(frame1,1)
%     pitch_period=frame1(ii,:);
%     avg_pitch_period=mean(pitch_period);
%     if avg_pitch_period ~=0
%         pp=pp+1;
%         for k1=1:length(pitch_period)-1
%             abs_pitch_period_diff(k1)=abs(pitch_period(k1)-pitch_period(k1+1));
%         end
% 
%         for k1=1:length(pitch_period)-2
%             abs_rltv_three_pitch_period_diff(k1)=abs(pitch_period(k1)-mean([pitch_period(k1+1),pitch_period(k1+2)]));
%         end
% 
%         for k1=1:length(pitch_period)-4
%             abs_rltv_five_pitch_period_diff(k1)=abs(pitch_period(k1)-mean([pitch_period(k1+1),pitch_period(k1+2),pitch_period(k1+3),pitch_period(k1+4)]));
%         end
% 
%         jitter_absolute=1000*mean(abs_pitch_period_diff);
%         jitter_relative=mean(abs_pitch_period_diff)./avg_pitch_period;
% 
%         jitter_rap=mean(abs_rltv_three_pitch_period_diff)./avg_pitch_period;
%         jitter_ppq=mean(abs_rltv_five_pitch_period_diff)./avg_pitch_period;
%         jitter_features=[jitter_absolute,jitter_relative,jitter_rap,jitter_ppq];
%         jitter(pp,:)=jitter_features;
%     end
% end
