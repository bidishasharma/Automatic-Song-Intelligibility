clc;
close all;
clear all;

% I am playing a single hand looks like a loosing game
[sig,Fs,nbits]=wavread('/home/queen/PHD/DATABASE/TIMIT/TEST/DR1/FAKS0/SA1.wav');
s=sig(:,1);


% ------------------------------------------Short-Time energy calculation-------------------------------------------

nWindows = 20*10^-3*Fs;
wRect = rectwin(nWindows);
winOverlap=nWindows/2;

sigFramed = buffer(s, nWindows,winOverlap);
sigWindowed = diag(wRect) * sigFramed;
ienergyST = sum(sigWindowed.^2,1);
En= ienergyST;En=En./max(En);


% Time in seconds, for the graphs
t = [0:length(s)-1]/Fs;

%------------------------------------------FILTERING THE SIGNAL-------------------------------------------------

ienergyST1(1)=ienergyST(1);
ienergyST1(length(ienergyST))=ienergyST(length(ienergyST));
winlen=3;

for i=2:length(ienergyST)-1
    ienergyST1(i)=(ienergyST(i-1)+ienergyST(i)+ienergyST(i+1))/winlen;
end


En_smoothed=ienergyST1./max(ienergyST1);

%---------------------------------------FINDING THE THRESHOLD---------------------------------

%M=median(ienergyST);
M=median(En_smoothed);
x=10^(2/10);
threshold=M;

for i=1:length(ienergyST)
  if En_smoothed(i)<threshold
    En_smoothed(i)=0;
  end
  
end

En_threshld=En_smoothed./max(En_smoothed);


% %%%%%%%%%%%%%%%%%%%%%%% peak enhancement%%%%%%%%%%%%%%%%%%
 [MSMSR]= peak_enhance(En_threshld',Fs);



%-----------------------------------------------FINDING THE PEAKS---------------------------------------------

[pks,locs]=findpeaks(En_threshld);
locs1=locs;
%----------------------------------------------FINDING PRECEDING DIPS------------------------------------------

j=0;

for i=1:length(locs)
        
    while locs(i)-1-j>0 & En_threshld(locs(i)-j)>=En_threshld(locs(i)-1-j)   
        j=j+1;
    end
    dip_locs(i) =(locs(i)-j);
    dip_en(i)=En_threshld(dip_locs(i));
    j=0;

end



%----------------------------------------IGNORE THE PEAKS OCCURING VERY CLOSE--------------------------------------


for i=1:length(locs)
    if pks(i)-dip_en(i)<0.035
        locs(i)=0;
    end
end

temp=zeros(1,length(ienergyST));
for i=1:length(locs)
    
           if locs(i)>0
                temp(locs(i))=1;
           end
 end
% x=10^(4/10);
% for i=2:length(pks)
%     if abs(pks(i)-pks(i-1))<x
%         temp(locs(i))=0;
%     end
% end

% temp(locs)=1;

%------------------------------------------------PLOTTING THE GRAPHS---------------------------------------

[ syll_no] = count_syll(temp);
syll_no

figure;
ax(1)=subplot(6,1,1);plot(s);
title('original signal')
ax(2)=subplot(6,1,2);plot(1:length(s)/length(En):length(s),En);
title('short term energy')
ax(3)=subplot(6,1,3);plot(1:length(s)/length(En_threshld):length(s),En_smoothed);
title('smoothed signal')
ax(4)=subplot(6,1,4);plot(1:length(s)/length(En_threshld):length(s),En_threshld);
title('ignoring the values below threshold')
ax(5)=subplot(6,1,5);plot(s);hold on;stem(1:length(s)/length(temp):length(s),temp,'r');

ax(6)=subplot(6,1,6);plot(1:length(s)/length(MSMSR):length(s),MSMSR,'r');linkaxes(ax,'x');
title('syllables')


% figure
% ax(1)=subplot(3,1,1);
% plot(En)
% ax(2)=subplot(3,1,2);
% plot(En_threshld);
% % ax(2)=subplot(3,1,2);plot(1:length(s)/length(En_threshld):length(s),En_threshld);
% ax(3)=subplot(3,1,3);
% % % stem(1:length(ienrgyST1)/length(pks):length(ienrgyST1),pks)
% % stem(1:length(s)/length(temp):length(s),temp);
% stem(temp);
% % linkaxes(ax,'x');

